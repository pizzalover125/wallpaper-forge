# Wallpaper Forge

Wallpapers are boring. Not anymore.

Features:

- Weather, Time, and Quote widgets
- Image filters
- Available on Windows, macOS, and Linux
- Gallery with awesome images
